% Clear workspace, command window, and close all figure windows
clc;
clear all;
close all;

% Load the input image (replace with your file path or use a built-in image)
img = imread('peppers.png'); % Built-in RGB image

% Resize the image to half of its original dimensions using imresize
resized_img = imresize(img, 0.5);

% Save the resized image to a file using imwrite
imwrite(resized_img, 'resized_image.png');
disp('Resized image saved as resized_image.png');

% Convert the image to grayscale
img_gray = rgb2gray(resized_img);

% Perform arithmetic operations
scalar = 50;
img_add = img_gray + scalar;            % Addition
img_subtract = img_gray - scalar;       % Subtraction
img_multiply = img_gray * 1.5;          % Multiplication (scaling)
img_divide = img_gray / 2;              % Division (scaling)

% Save the processed images
imwrite(img_add, 'image_addition.png');
imwrite(img_subtract, 'image_subtraction.png');
imwrite(img_multiply, 'image_multiplication.png');
imwrite(img_divide, 'image_division.png');
disp('Processed images saved as image_addition.png, image_subtraction.png, image_multiplication.png, and image_division.png');

% Display the results
figure;
subplot(2, 3, 1);
imshow(resized_img);
title('Resized Image');

subplot(2, 3, 2);
imshow(img_gray);
title('Grayscale Image');

subplot(2, 3, 4);
imshow(img_add, []);
title('Image After Addition');

subplot(2, 3, 5);
imshow(img_subtract, []);
title('Image After Subtraction');

subplot(2, 3, 6);
imshow(img_multiply, []);
title('Image After Multiplication');
