clc;
clear all;
close all;
img1 = imread("cameraman.tif");
img2 = histeq(img1);
figure;
subplot( 2, 2, 1); imshow(img2); title("Histogram equivalent");