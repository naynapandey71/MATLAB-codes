clc; clear; close all;

% Time and frequency vectors
t = -5:0.01:5;
f = linspace(-10, 10, length(t));

% Original signal and Fourier Transform
x = exp(-t.^2);
X = fftshift(fft(x));

% Time-scaling factor
a = 2;

% Scaled signal and its Fourier Transform
x_scaled = exp(-(t / a).^2);
X_scaled = abs(a) * fftshift(fft(x_scaled));

% Plot results
subplot(2, 2, 1), 
plot(t, x), 
title('Original Signal x(t)'), 
xlabel('Time'), ylabel('Amplitude'), 
grid on;

subplot(2, 2, 2),
plot(f, abs(X)), 
title('Fourier Transform |X(f)|'),
xlabel('Frequency'), ylabel('Amplitude'), 
grid on;

subplot(2, 2, 3), 
plot(t, x_scaled), 
title(['Scaled Signal x(at), a = ' num2str(a)]),
xlabel('Time'), ylabel('Amplitude'), 
grid on;

subplot(2, 2, 4),
plot(f, abs(X_scaled)), 
title(['Fourier Transform |X(f/a)|, a = ' num2str(a)]),
xlabel('Frequency'), ylabel('Amplitude'),
grid on;
