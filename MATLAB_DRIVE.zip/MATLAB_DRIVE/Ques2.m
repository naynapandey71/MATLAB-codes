% Clear workspace and command window
clc;           % Clear command window
clear all;     % Clear all variables

% Define the range of x-values
x = 0:0.1:10;  % x ranges from 0 to 10 with steps of 0.1

% Define the linear function
y1 = 2*x + 3;   % Linear equation: y1 = 2x + 3
% Define the quadratic function
y2 = 2*x.^2 + 3*x + 2;   % Quadratic equation: y2 = 2x^2 + 3x + 2
% Define the trigonometric function
y3 = sin(x);

% Plot both functions on the same graph
figure;        % Create a new figure window
plot(x, y1);  % Plot linear function in blue
hold on;       % Hold the current plot to add more functions
plot(x, y2);  % Plot quadratic function in red
hold on;
plot(x, y3);

% Add labels and title
xlabel('x');                      % Label for x-axis
ylabel('y');                      % Label for y-axis
title('Graphs of Linear, Quadratic Functions and trigonometric functions');  % Title for the graph

