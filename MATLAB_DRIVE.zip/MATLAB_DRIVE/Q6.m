% Clear workspace, command window, and close all figure windows
clc;
clear all;
close all;

% Load the image (replace with your file path or use a built-in image)
img = imread('peppers.png'); % Built-in RGB image

% Display the original image
figure;
imshow(img);
title('Original Image');

% Calculate the negative of the image
img_negative = 255 - img; % Subtract pixel values from 255

% Display the negative image
figure;
imshow(img_negative);
title('Negative Image');
