clc;
clear all;
close all;

im1 = imread("cameraman.tif"); % Read the image
figure, imshow(im1); % Display the image

% Save the image as a PNG file with a proper extension
imwrite(im1, "new_image.png");
