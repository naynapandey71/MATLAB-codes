% Clear workspace, command window, and close all figure windows
clc;
clear all;
close all;

% Read two grayscale images
img1 = imread('cameraman.tif');
img2 = imread('moon.tif');

% Resize both images to 128x128
r1 = imresize(img1, [128, 128]);
r2 = imresize(img2, [128, 128]);

% Perform arithmetic operations
im3 = r1 + r2;           % Addition
im4 = r1 - r2;           % Subtraction
im5 = r1 .* r2;          % Element-wise multiplication
im6 = r1 ./ (r2 + 1);    % Element-wise division (avoid division by zero)

% Save results to separate files
imwrite(im3, "added.tif");
imwrite(im4, "subtracted.tif");
imwrite(im5, "multiplied.tif");
imwrite(im6, "divided.tif");

% Display results
figure;
subplot(2, 2, 1); imshow(im3); title("Added");
subplot(2, 2, 2); imshow(im4); title("Subtracted");
subplot(2, 2, 3); imshow(im5); title("Multiplied");
subplot(2, 2, 4); imshow(im6); title("Divided");
