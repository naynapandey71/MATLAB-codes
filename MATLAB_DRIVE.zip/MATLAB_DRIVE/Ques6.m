clc;
clear all;
close all;

% Read the input image
im1 = imread('cameraman.tif'); % Replace 'peppers.jpg' with your image file name

% Compute the negative of the image
negativeImage = 255 - im1;

% Display the input image and its negative
figure;
subplot(1, 2, 1);
imshow(im1);
title('Input Image');

subplot(1, 2, 2);
imshow(negativeImage);
title('Negative Image');
