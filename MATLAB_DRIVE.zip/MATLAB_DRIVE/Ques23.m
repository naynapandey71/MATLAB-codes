clc; clear; close all;

% Read and display the input image
img = im2double(imread('cameraman.tif')); % Load and normalize image
figure, imshow(img), title('Original Image');

% Fourier Transform and shift
F = fftshift(fft2(img)); 

% Create a circular low-pass filter
[m, n] = size(img);
D0 = 30; % Cutoff frequency
[u, v] = meshgrid(-n/2:n/2-1, -m/2:m/2-1);
H = double(sqrt(u.^2 + v.^2) <= D0);

% Apply the filter
F_filtered = F .* H;

% Inverse Fourier Transform
img_filtered = real(ifft2(ifftshift(F_filtered)));

% Display results
figure;
subplot(1, 3, 1), imshow(log(1 + abs(F)), []), title('Fourier Spectrum');
subplot(1, 3, 2), imshow(H, []), title('Low-Pass Filter');
subplot(1, 3, 3), imshow(img_filtered, []), title('Filtered Image');
