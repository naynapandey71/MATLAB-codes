clc;
clear all;
close all;

im1 = imread("cameraman.tif");
im2 = imread("moon.tif");

r1 = imresize(im1,[128,128]);
r2 = imresize(im2,[128,128]);

im3 = r1 + r2;
im4 = r1 - r2;

im5 = r1 .* r2;
im6 = r1 ./ r2;

imwrite(im3,"added.jpg");
imwrite(im5,"multipled.jpg");
imwrite(im4,"subtracted.jpg");
imwrite(im6,"divided.jpg");


figure;
subplot(3,2,1); imshow(r1, []); title("Original Image 1");
subplot(3,2,2); imshow(r2, []); title("Original Image 2");
subplot(3,2,3); imshow(im1, []); title("Added");
subplot(3,2,4); imshow(im2, []); title("Substract");
subplot(3,2,5); imshow(im3, []); title("Multiplied");
subplot(3,2,6); imshow(im4, []); title("Divided");