clc; clear; close all;

% Step 1: Load the input image and convert to grayscale
img = imread('cameraman.tif'); % You can replace this with your image
gray_img = im2double(img);

% Step 2: Apply edge detection using different operators
sobel_edges = edge(gray_img, 'sobel');
canny_edges = edge(gray_img, 'canny');
roberts_edges = edge(gray_img, 'roberts');
prewitt_edges = edge(gray_img, 'prewitt');

% Step 3: Display the original image and edge-detected images
figure;
subplot(2, 3, 1), imshow(gray_img), title('Original Image');
subplot(2, 3, 2), imshow(sobel_edges), title('Sobel Operator');
subplot(2, 3, 3), imshow(canny_edges), title('Canny Operator');
subplot(2, 3, 4), imshow(roberts_edges), title('Roberts Operator');
subplot(2, 3, 5), imshow(prewitt_edges), title('Prewitt Operator');
