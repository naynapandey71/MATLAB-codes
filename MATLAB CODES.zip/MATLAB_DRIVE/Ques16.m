clc;
clear all;
close all;

img=imread("peppers.png");
im=rgb2gray(img);
a=imnoise(im,"gaussian");
figure,
subplot(131), imshow(a), title('Gaussian Noise');

filteredimage=medfilt2(a,[3 3]);
subplot(132), imshow(uint8(filteredimage)), title('3 X 3 median filter');

filter=1/9*ones(3,3);
filteredimage=conv2(a,filter);
subplot(142), imshow(uint8(filteredimage)), title('3 X 3 average filter');

filteredimage=medfilt2(a,[5 5]);
subplot(133), imshow(uint8(filteredimage)), title('5 X 5 median filter');

filter=1/25*ones(5,5);
filteredimage=conv2(a,filter);
subplot(143), imshow(uint8(filteredimage)), title('5 X 5 average filter');

a=imnoise(im,"salt & pepper");
figure,
subplot(131), imshow(a), title('Salt & Pepper Noise');

filteredimage=medfilt2(a,[3 3]);
subplot(132), imshow(uint8(filteredimage)), title('3 X 3 median filter');

filter=1/9*ones(3,3);
filteredimage=conv2(a,filter);
subplot(142), imshow(uint8(filteredimage)), title('3 X 3 average filter');

filteredimage=medfilt2(a,[5 5]);
subplot(133), imshow(uint8(filteredimage)), title('5 X 5 median filter');

filter=1/25*ones(5,5);
filteredimage=conv2(a,filter);
subplot(143), imshow(uint8(filteredimage)), title('5 X 5 average filter');

a=imnoise(im,"speckle");
figure,
subplot(131), imshow(a), title('Speckle Noise');

filteredimage=medfilt2(a,[3 3]);
subplot(132), imshow(uint8(filteredimage)), title('3 X 3 median filter');

filter=1/9*ones(3,3);
filteredimage=conv2(a,filter);
subplot(142), imshow(uint8(filteredimage)), title('3 X 3 average filter');

filteredimage=medfilt2(a,[5 5]);
subplot(133), imshow(uint8(filteredimage)), title('5 X 5 median filter');

filter=1/25*ones(5,5);
filteredimage=conv2(a,filter);
subplot(143), imshow(uint8(filteredimage)), title('5 X 5 average filter');
