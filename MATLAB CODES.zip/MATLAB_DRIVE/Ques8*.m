% Read the input image
img = imread('inputImage.jpg'); % Replace with your image file

% Divide the image into four quadrants
[rows, cols, ~] = size(img);
LL = img(1:rows/2, 1:cols/2, :);               % Top-left
LH = img(1:rows/2, cols/2+1:end, :);          % Top-right
HL = img(rows/2+1:end, 1:cols/2, :);          % Bottom-left
HH = img(rows/2+1:end, cols/2+1:end, :);      % Bottom-right

% Reconstruct the image
reconstructedImg = [LL, LH; HL, HH];

% Display and save
imshow(reconstructedImg);
imwrite(reconstructedImg, 'reconstructedImage.jpg');
