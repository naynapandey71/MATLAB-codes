% Load the input image
inputImage = imread('cameraman.tif'); % Replace with your image file
imshow(inputImage), title('Original Image');

% Translation
tx = 50; % Translate by 50 pixels right
ty = 30; % Translate by 30 pixels down
translatedImage = imtranslate(inputImage, [tx, ty]);
figure, imshow(translatedImage), title('Translated Image');

% Rotation
angle = 45; % Rotate by 45 degrees
rotatedImage = imrotate(inputImage, angle);
figure, imshow(rotatedImage), title('Rotated Image');

% Scaling
scaleFactor = 1.5; % Scale by 1.5 times
scaledImage = imresize(inputImage, scaleFactor);
figure, imshow(scaledImage), title('Scaled Image');

% Horizontal Shear
shx = 0.5; % Horizontal shear factor
tform_shear_h = affine2d([1 shx 0; 0 1 0; 0 0 1]);
shearedImageH = imwarp(inputImage, tform_shear_h, 'OutputView', imref2d(size(inputImage)));
figure, imshow(shearedImageH), title('Horizontally Sheared Image');

% Vertical Shear
shy = 0.3; % Vertical shear factor
tform_shear_v = affine2d([1 0 0; shy 1 0; 0 0 1]);
shearedImageV = imwarp(inputImage, tform_shear_v, 'OutputView', imref2d(size(inputImage)));
figure, imshow(shearedImageV), title('Vertically Sheared Image');
