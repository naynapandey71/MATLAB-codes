clc;
clear all;
close all;

% Convert and resize the input image
gray = im2gray(img);
a = imresize(gray, [256, 256]);

% Display the image
imshow(a);

% Initialize the quadrants
LL = zeros(128);
LH = zeros(128);
HL = zeros(128);
HH = zeros(128);

% LL Component
for i = 1:128
    for j = 1:128
        LL(i,j) = a(i,j);
    end
end

% LH Component
for i = 1:128
    for j = 129:256
        LH(i,j-128) = a(i,j);
    end
end

% HL Component
for i = 129:256
    for j = 1:128
        HL(i-128,j) = a(i,j);
    end
end

% HH Component
for i = 129:256
    for j = 129:256
        HH(i-128,j-128) = a(i,j);
    end
end
