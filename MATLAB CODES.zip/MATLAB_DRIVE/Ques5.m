% Clear the workspace, command window, and close all figure windows
clc;           % Clear the command window
clear all;     % Clear all variables from the workspace
close all;     % Close all figure windows

% Load the image
img = imread('peppers.png');


% Convert the image to grayscale
g1 = rgb2gray(img);

% Convert the grayscale image to a binary image
threshold = 0.5;             % Define a threshold (between 0 and 1)
b1 = imbinarize(g1, threshold);  % Convert to binary using the threshold

% Display the binary image
figure;                      % Create a new figure window
imshow(b1);                  % Display the binary image
title("Binary Image");       % Add a title to the image
