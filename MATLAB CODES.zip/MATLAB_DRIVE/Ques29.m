clc;
clear all;
close all;

% Step 1: Read the image
img1 = imread('peppers.png');
imshow(img1); % Display the original image

% Step 2: Apply motion blur
len = 11;   % Length of the motion blur
theta = 31; % Angle of the motion blur
img = fspecial('motion', len, theta); % Create motion blur filter
blurredImg = imfilter(img1, img, 'replicate'); % Apply the blur to the image
figure;
imshow(blurredImg); % Display the blurred image

