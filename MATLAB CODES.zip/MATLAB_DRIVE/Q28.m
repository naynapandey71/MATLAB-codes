
clc;
clear all;
close all;
img1 = imread("peppers.png");

i = rgb2hsv(img1);
imshow(i);