clc;
clear all;
close all;

a=imread("peppers.png");
a=rgb2gray(a);

[m,n]=size(a);

%7th Bitplane image
for i=1:m
    for j=1:n
        b7(i,j)=bitand(a(i,j),128);
    end
end

%6th Bitplane image
for i=1:m
    for j=1:n
        b6(i,j)=bitand(a(i,j),64);
    end
end

%5th Bitplane image
for i=1:m
    for j=1:n
        b5(i,j)=bitand(a(i,j),32);
    end
end

%4th Bitplane image
for i=1:m
    for j=1:n
        b4(i,j)=bitand(a(i,j),16);
    end
end

%3th Bitplane image
for i=1:m
    for j=1:n
        b3(i,j)=bitand(a(i,j),8);
    end
end

%2th Bitplane image
for i=1:m
    for j=1:n
        b2(i,j)=bitand(a(i,j),4);
    end
end

%1th Bitplane image
for i=1:m
    for j=1:n
        b1(i,j)=bitand(a(i,j),2);
    end
end

%0th Bitplane image
for i=1:m
    for j=1:n
        b0(i,j)=bitand(a(i,j),1);
    end
end

figure,
subplot(331), imshow(a), title("Original image");
subplot(332), imshow(b7), title("7th Bitplane image");
subplot(333), imshow(b6), title("6th Bitplane image");
subplot(334), imshow(b5), title("5th Bitplane image");
subplot(335), imshow(b4), title("4th Bitplane image");
subplot(336), imshow(b3), title("3rd Bitplane image");
subplot(337), imshow(b2), title("2nd Bitplane image");
subplot(338), imshow(b1), title("1st Bitplane image");
subplot(339), imshow(b0), title("0th Bitplane image");