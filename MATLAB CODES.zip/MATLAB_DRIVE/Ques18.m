clc;
clear all;
close all;

a=imread("cameraman.tif");

b=imnoise(a,"gaussian");
c=imnoise(a,"salt & pepper");
d=imnoise(a,"speckle");

weightfilter=1/16*[1 2 1; 2 4 2; 1 2 1];

% convolution increases the size of the image so we use 'same'

wgaussian=conv2(b,weightfilter,'same');
wsaltandpepper=conv2(c,weightfilter,'same');
wspeckle=conv2(d,weightfilter,'same');

figure,
subplot(131), imshow(a), title("Original image")
subplot(132), imshow(b), title("Gaussian noise image");
subplot(133), imshow(uint8(wgaussian)), title("Weighted Filtered image");

figure,
subplot(131), imshow(a), title("Original image")
subplot(132), imshow(c), title("Salt and Pepper noise image");
subplot(133), imshow(uint8(wsaltandpepper)), title("Weighted Filtered image");

figure,
subplot(131), imshow(a), title("Original image")
subplot(132), imshow(d), title("Speckle noise image");
subplot(133), imshow(uint8(wspeckle)), title("Weighted Filtered image");