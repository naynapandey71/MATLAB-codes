clc;           % Clear the command window
clear all;     % Clear all variables
close all;     % Close all figures

% Read the image
img = imread("peppers.png");

% Convert the image to grayscale
a = rgb2gray(img);

% Display the original image
subplot(1, 4, 1), imshow(a), title('Original Image');

% Apply a 3x3 filter
filter = (1/9) * ones(3, 3); % Define the filter
filteredimage = conv2(double(a), filter, 'same'); % Convolution with 'same' to keep original size
subplot(1, 4, 2), imshow(uint8(filteredimage)), title('3x3 Filter');

% Apply a 5x5 filter
filter = (1/25) * ones(5, 5); % Define the filter
filteredimage = conv2(double(a), filter, 'same'); % Convolution with 'same' to keep original size
subplot(1, 4, 3), imshow(uint8(filteredimage)), title('5x5 Filter');

% Apply a 7x7 filter
filter = (1/49) * ones(7, 7); % Define the filter
filteredimage = conv2(double(a), filter, 'same'); % Convolution with 'same' to keep original size
subplot(1, 4, 4), imshow(uint8(filteredimage)), title('7x7 Filter');
