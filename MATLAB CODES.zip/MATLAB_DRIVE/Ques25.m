clc; clear; close all;

% Load and normalize the image
img = im2double(imread('cameraman.tif'));

% Add noise to the image
noisy_images = { ...
    imnoise(img, 'gaussian', 0, 0.01), ...       % Gaussian noise
    imnoise(img, 'salt & pepper', 0.02), ...    % Salt & Pepper noise
    imnoise(img, 'speckle', 0.04)};             % Speckle noise
noise_titles = {'Gaussian Noise', 'Salt & Pepper Noise', 'Speckle Noise'};

% Low-pass filter function
apply_low_pass = @(noisy_img, D0) real(ifft2(ifftshift( ...
    fftshift(fft2(noisy_img)) .* double(sqrt(meshgrid(-size(noisy_img,2)/2:size(noisy_img,2)/2-1, ...
    -size(noisy_img,1)/2:size(noisy_img,1)/2-1).^2 + ...
    meshgrid(-size(noisy_img,1)/2:size(noisy_img,1)/2-1, ...
    -size(noisy_img,2)/2:size(noisy_img,2)/2-1)'.^2) <= D0))));

% Cutoff frequency for low-pass filter
D0 = 30;

% Apply low-pass filtering and store results
filtered_images = cellfun(@(img) apply_low_pass(img, D0), noisy_images, 'UniformOutput', false);

% Display original, noisy, and filtered images
figure;
subplot(2, 4, 1), imshow(img), title('Original Image');
for i = 1:3
    subplot(2, 4, i+1), imshow(noisy_images{i}), title(noise_titles{i});
    subplot(2, 4, i+5), imshow(filtered_images{i}, []), title(['Filtered ' noise_titles{i}]);
end
