clc;
clear all;
close all;

% Read the images
a = imread("cameraman.tif");
b = imread("peppers.jpg");
b = rgb2gray(b);  % Convert to grayscale
b = imresize(b, [256, 256]);  % Resize to match dimensions of 'a'

% Compute FFT of both images
ffta = fft2(a);
fftb = fft2(b);

% Magnitude and phase
mag_a = abs(ffta);
ph_a = angle(ffta);

mag_b = abs(fftb);
ph_b = angle(fftb);

% Construct new FFTs with interchanged magnitude and phase
newffta = mag_a .* exp(1i * ph_b);
newfftb = mag_b .* exp(1i * ph_a);

% Compute inverse FFT to get the modified images
iffta = uint8(mat2gray(abs(ifft2(newffta))) * 255);  % Scale to display range
ifftb = uint8(mat2gray(abs(ifft2(newfftb))) * 255);  % Scale to display range

% Display the results
figure;
subplot(221), imshow(a), title('Original Image a');
subplot(222), imshow(b), title('Original Image b');
subplot(223), imshow(iffta), title('Phase Interchange (Image a)');
subplot(224), imshow(ifftb), title('Phase Interchange (Image b)');
