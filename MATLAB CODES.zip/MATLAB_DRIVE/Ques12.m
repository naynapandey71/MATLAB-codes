clc;
clear;
close all;

% Read the input image
img = imread('peppers.png');

% Normalize the image to [0, 1]
img = double(img) / 255;

% Gamma values to test
gamma_values = [0.2, 0.5, 1, 1.5, 2.2];

% Display the original image
figure;
subplot(2, 3, 1);
imshow(img);
title('Original Image');

% Apply gamma transformation and display for each gamma value
for i = 1:length(gamma_values)
    imshow(uint8(img.^gamma_values(i) * 255)); % Apply gamma and rescale
    title(['Gamma = ' num2str(gamma_values(i))]);
    subplot(2, 3, i + 1);
end
