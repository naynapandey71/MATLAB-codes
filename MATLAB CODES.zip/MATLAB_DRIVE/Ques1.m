% Simplified MATLAB Script for Matrix Indexing and Accessing

% Prompt user to input a matrix
disp('Enter a matrix: ');
matrix = input('Matrix: ');

% Display the matrix
disp('The entered matrix is:');
disp(matrix);

% Access a specific element (row 1, column 2)
element_rowcol = matrix(2, 2);
disp(['Element at row 1, column 2 is:',num2str(element_rowcol)]);

% Access a specific row (row 2)
row2 = matrix(2, :);
disp('Row 2 is:');
disp(row2);

% Access a specific column (column 3)
column3 = matrix(:, 3);
disp('Column 3 is:');
disp(column3);

% Access a small part (first 2 rows and 2 columns)
subMatrix = matrix(1:2, 1:2);
disp('The first 2 rows and 2 columns are:');
disp(subMatrix);

% Find all elements greater than 5
greaterThan5 = matrix(matrix > 5);
disp('Elements greater than 5 are:');
disp(greaterThan5);

% End of script


