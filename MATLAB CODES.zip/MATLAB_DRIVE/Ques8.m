clc;            % Clear the command window
clear all;      % Clear all variables
close all;      % Close all figures

% Load the input image (replace 'img' with your actual image variable or file path)
img = imread('cameraman.tif'); % Load an image (modify 'input_image.jpg' with your file)

% Convert the image to grayscale
gray = im2gray(img);

% Resize the grayscale image to 256x256 pixels
a = imresize(gray, [256, 256]);

% Display the resized image
imshow(a);
title('Resized Grayscale Image');

% Initialize matrices for the four components
LL = zeros(128, 128); % Top-left quadrant
LH = zeros(128, 128); % Top-right quadrant
HL = zeros(128, 128); % Bottom-left quadrant
HH = zeros(128, 128); % Bottom-right quadrant

% Extract the LL (Top-Left) Component
for i = 1:128
    for j = 1:128
        LL(i, j) = a(i, j);
    end
end

% Extract the LH (Top-Right) Component
for i = 1:128
    for j = 129:256
        LH(i, j-128) = a(i, j);
    end
end

% Extract the HL (Bottom-Left) Component
for i = 129:256
    for j = 1:128
        HL(i-128, j) = a(i, j);
    end
end

% Extract the HH (Bottom-Right) Component
for i = 129:256
    for j = 129:256
        HH(i-128, j-128) = a(i, j);
    end
end

% Display the four components for verification
figure;
subplot(2, 2, 1);
imshow(uint8(LL));
title('LL (Top-Left)');

subplot(2, 2, 2);
imshow(uint8(LH));
title('LH (Top-Right)');

subplot(2, 2, 3);
imshow(uint8(HL));
title('HL (Bottom-Left)');

subplot(2, 2, 4);
imshow(uint8(HH));
title('HH (Bottom-Right)');
