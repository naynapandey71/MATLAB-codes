clc;
clear all;
close all;

img = imread("peppers.png");
im = rgb2gray(img);
a = imnoise(im,"gaussian");
figure,
subplot(141), imshow(a), title('Gaussian Noise');

filter = 1/9*ones(3,3);
filteredimage = conv2(a,filter);
subplot(142), imshow(uint8(filteredimage)), title('3 X 3 filter');

filter = 1/25*ones(5,5);
filteredimage = conv2(a,filter);
subplot(143), imshow(uint8(filteredimage)), title('5 X 5 filter');

filter = 1/49*ones(7,7);
filteredimage = conv2(a,filter);
subplot(144), imshow(uint8(filteredimage)), title('7 X 7 filter');

a = imnoise(im,"salt & pepper");
figure,
subplot(141), imshow(a), title('Salt & Pepper Noise');

filter = 1/9*ones(3,3);
filteredimage = conv2(a,filter);
subplot(142), imshow(uint8(filteredimage)), title('3 X 3 filter');

filter=1/25*ones(5,5);
filteredimage=conv2(a,filter);
subplot(143), imshow(uint8(filteredimage)), title('5 X 5 filter');

filter=1/49*ones(7,7);
filteredimage=conv2(a,filter);
subplot(144), imshow(uint8(filteredimage)), title('7 X 7 filter');

a=imnoise(im,"speckle");
figure,
subplot(141), imshow(a), title('Speckle Noise');

filter=1/9*ones(3,3);
filteredimage=conv2(a,filter);
subplot(142), imshow(uint8(filteredimage)), title('3 X 3 filter');

filter=1/25*ones(5,5);
filteredimage=conv2(a,filter);
subplot(143), imshow(uint8(filteredimage)), title('5 X 5 filter');

filter=1/49*ones(7,7);
filteredimage=conv2(a,filter);
subplot(144), imshow(uint8(filteredimage)), title('7 X 7 filter');