% Load the input image
inputImage = imread('cameraman.tif'); % Replace with your image file
imshow(inputImage), title('Original Image');

% Use the interactive cropping tool
disp('Use the mouse to draw a rectangle to crop the image.');
croppedImage = imcrop(inputImage); % Interactive crop tool

% Display the cropped image
figure, imshow(croppedImage), title('Cropped Image');
