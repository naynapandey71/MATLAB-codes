% Clear workspace, command window, and close all figure windows
clc;           % Clear the command window
clear    % Clear all variables from the workspace
close all;     % Close all figure windows

% Load the image
img1 = imread("C:\Users\Nayna Pandey\Downloads\cameraman.jpeg");

% Convert the image to grayscale
g1 = rgb2gray(img1);

% Display the original image and grayscale image side by side
figure;                      % Create a new figure window
subplot(1, 2, 1);            % Create a subplot with 1 row, 2 columns, and set to the first column
imshow(img1);                % Display the original image
title("Original Image");     % Add title to the first plot

subplot(1, 2, 2);            % Create a subplot with 1 row, 2 columns, and set to the second column
imshow(g1);                  % Display the grayscale image
title("Grayscale Image");    % Add title to the second plot
