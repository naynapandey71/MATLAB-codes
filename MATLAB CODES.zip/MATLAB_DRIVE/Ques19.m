clc;
clear;
close all;

% Read the input image and convert it to grayscale
img = rgb2gray(imread('peppers.png')); 

% Perform the forward Discrete Fourier Transform (FFT)
dft = fft2(double(img));

% Perform the inverse Discrete Fourier Transform (IFFT)
reconstructed_img = ifft2(dft);

% Display the original image, magnitude spectrum, and the reconstructed image
subplot(1, 3, 1), imshow(img), title('Original Image');
subplot(1, 3, 2), imshow(log(1 + abs(fftshift(dft))), []), title('Magnitude Spectrum');
subplot(1, 3, 3), imshow(real(reconstructed_img), []), title('Reconstructed Image');
